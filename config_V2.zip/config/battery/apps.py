from django.apps import AppConfig


class BatteryConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "battery"
